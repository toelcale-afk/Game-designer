package com.aistudio.packflow.xkrv.installer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

enum class InstallerScreen { Pick, Preview, Log }

/**
 * Process-level state so folding/unfolding the Fold (a config change) doesn't
 * lose the parsed APK or cancel work in progress.
 */
object InstallerSession {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    var screen by mutableStateOf(InstallerScreen.Pick)
    var apk by mutableStateOf<ApkInfo?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    fun open(context: Context, uri: Uri) {
        busy = true
        message = null
        InstallEvents.set(InstallState.Idle)
        scope.launch {
            try {
                apk = ApkInspector.inspect(context.applicationContext, uri)
                screen = InstallerScreen.Preview
            } catch (t: Throwable) {
                ErrorLog.error("Could not read the selected file", t)
                message = t.message ?: "Could not read the selected file"
            } finally {
                busy = false
            }
        }
    }

    fun install(context: Context) {
        val info = apk ?: return
        scope.launch { ApkInstaller.install(context.applicationContext, info.file) }
    }
}

/** Entry point. Call from MainActivity's setContent { ... } or from a tab/route. */
@Composable
fun PackFlowInstaller(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    remember { ErrorLog.init(context); true }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) InstallerSession.open(context, uri)
    }
    val pick = {
        picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream"))
    }

    BackHandler(enabled = InstallerSession.screen != InstallerScreen.Pick) {
        InstallerSession.screen =
            if (InstallerSession.screen == InstallerScreen.Log && InstallerSession.apk != null)
                InstallerScreen.Preview else InstallerScreen.Pick
    }

    Surface(modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (InstallerSession.screen) {
            InstallerScreen.Pick -> PickScreen(onPick = pick)
            InstallerScreen.Preview -> InstallerSession.apk?.let { ApkPreviewScreen(it, onPickAnother = pick) }
                ?: PickScreen(onPick = pick)
            InstallerScreen.Log -> ErrorLogScreen(onBack = {
                InstallerSession.screen =
                    if (InstallerSession.apk != null) InstallerScreen.Preview else InstallerScreen.Pick
            })
        }
    }
}

@Composable
private fun PickScreen(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("APK Installer", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose an .apk to check its name, version, permissions and signature before installing.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        if (InstallerSession.busy) {
            CircularProgressIndicator()
            Spacer(Modifier.height(8.dp))
            Text("Reading APK…")
        } else {
            Button(onClick = onPick) { Text("Choose APK file") }
        }
        InstallerSession.message?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = { InstallerSession.screen = InstallerScreen.Log }) { Text("View error log") }
    }
}

@Composable
private fun ApkPreviewScreen(info: ApkInfo, onPickAnother: () -> Unit) {
    // Wide layout on the Fold's inner screen, single column on the cover screen.
    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (maxWidth >= 700.dp) {
            Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Header(info); Spacer(Modifier.height(12.dp)); Actions(info, onPickAnother)
                    Spacer(Modifier.height(12.dp)); Details(info)
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Signing(info); Spacer(Modifier.height(12.dp)); Permissions(info)
                }
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                Header(info); Spacer(Modifier.height(12.dp)); Actions(info, onPickAnother)
                Spacer(Modifier.height(12.dp)); Details(info)
                Spacer(Modifier.height(12.dp)); Signing(info)
                Spacer(Modifier.height(12.dp)); Permissions(info)
            }
        }
    }
}

@Composable
private fun Header(info: ApkInfo) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val icon = info.icon
        if (icon != null) {
            Image(icon.asImageBitmap(), contentDescription = "App icon",
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)))
        } else {
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center) { Text("APK") }
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(info.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(info.packageName, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            Text("Version ${info.versionName ?: "?"} (${info.versionCode})", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun Actions(info: ApkInfo, onPickAnother: () -> Unit) {
    val context = LocalContext.current
    val state by InstallEvents.state.collectAsState()
    val allowed = ApkInstaller.canInstall(context)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            if (!allowed) {
                Text("PackFlow needs permission to install apps. Turn on \"Allow from this source\", then come back.",
                    style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { context.startActivity(ApkInstaller.unknownSourcesSettings(context)) }) {
                    Text("Open install permission")
                }
            } else {
                val working = state is InstallState.Writing || state is InstallState.WaitingForUser
                Button(onClick = { InstallerSession.install(context) }, enabled = !working,
                    modifier = Modifier.fillMaxWidth()) { Text("Install ${info.label}") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPickAnother) { Text("Choose another") }
                OutlinedButton(onClick = { InstallerSession.screen = InstallerScreen.Log }) { Text("Error log") }
            }
            val (text, isError) = when (val s = state) {
                InstallState.Idle -> null to false
                InstallState.Writing -> "Preparing install…" to false
                InstallState.WaitingForUser -> "Confirm in the system dialog." to false
                is InstallState.Success -> "Installed." to false
                is InstallState.Failed -> s.reason to true
            }
            if (text != null) {
                Spacer(Modifier.height(8.dp))
                Text(text, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun Details(info: ApkInfo) {
    Section("Details") {
        Field("File", info.fileName)
        Field("Size", "%.2f MB".format(info.sizeBytes / 1_048_576.0))
        Field("Min / target SDK", "${info.minSdk ?: "?"} / ${info.targetSdk ?: "?"}")
        Field("File SHA-256", info.fileSha256, mono = true, copyable = true)
    }
}

@Composable
private fun Signing(info: ApkInfo) {
    Section("Signing") {
        if (info.signers.isEmpty()) {
            Text("No signing certificate found. Android will refuse to install this APK.",
                color = MaterialTheme.colorScheme.error)
        }
        info.signers.forEachIndexed { i, s ->
            if (i > 0) Spacer(Modifier.height(10.dp))
            Field("Subject", s.subject)
            Field("Cert SHA-256", s.sha256, mono = true, copyable = true)
            Field("Cert SHA-1", s.sha1, mono = true, copyable = true)
            if (s.isDebugKey) Text("Debug key: fine for testing, not for release.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
        }
    }
}

@Composable
private fun Permissions(info: ApkInfo) {
    val sensitive = info.permissions.count { it.sensitive }
    Section("Permissions (${info.permissions.size}, $sensitive sensitive)") {
        if (info.permissions.isEmpty()) Text("No permissions requested.")
        info.permissions.forEach { p ->
            Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name.removePrefix("android.permission."),
                    style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f))
                if (p.sensitive) Text("sensitive", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun Field(label: String, value: String, mono: Boolean = false, copyable: Boolean = false) {
    val context = LocalContext.current
    Column(Modifier.padding(vertical = 3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            if (copyable) TextButton(onClick = { copy(context, label, value) }) { Text("Copy") }
        }
        SelectionContainer {
            Text(value, style = MaterialTheme.typography.bodySmall,
                fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)
        }
    }
}

@Composable
private fun ErrorLogScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Error log", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Back") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { copy(context, "PackFlow installer log", ErrorLog.asText()) },
                enabled = ErrorLog.entries.isNotEmpty()) { Text("Copy log") }
            OutlinedButton(onClick = { ErrorLog.clear() }) { Text("Clear") }
        }
        Spacer(Modifier.height(12.dp))
        if (ErrorLog.entries.isEmpty()) {
            Text("Nothing logged yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            SelectionContainer {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(ErrorLog.entries.reversed()) { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            color = if (" ERROR " in line) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
            }
        }
    }
}

private fun copy(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
}
