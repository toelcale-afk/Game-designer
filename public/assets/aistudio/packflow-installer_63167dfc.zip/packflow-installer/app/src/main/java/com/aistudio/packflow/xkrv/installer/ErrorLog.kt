package com.aistudio.packflow.xkrv.installer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * App-wide installer log. Kept in memory for the UI and mirrored to
 * filesDir/installer_log.txt so it survives restarts. Never logs secrets.
 */
object ErrorLog {
    private const val TAG = "PackFlowInstaller"
    private const val FILE_NAME = "installer_log.txt"
    private const val MAX_LINES = 400

    val entries = mutableStateListOf<String>()
    private var file: File? = null
    private val main = Handler(Looper.getMainLooper())
    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun init(context: Context) {
        if (file != null) return
        val f = File(context.applicationContext.filesDir, FILE_NAME)
        file = f
        val old = runCatching { if (f.exists()) f.readLines().takeLast(MAX_LINES) else emptyList() }
            .getOrDefault(emptyList())
        runOnMain { entries.addAll(old) }
    }

    fun info(message: String) = add("INFO ", message, null)
    fun error(message: String, t: Throwable? = null) = add("ERROR", message, t)

    @Synchronized
    private fun add(level: String, message: String, t: Throwable?) {
        val detail = t?.let { " | ${it::class.java.simpleName}: ${it.message}" } ?: ""
        val line = "${stamp.format(Date())} $level $message$detail"
        if (level == "ERROR") Log.e(TAG, line, t) else Log.i(TAG, line)
        runCatching { file?.appendText(line + "\n") }
        runOnMain {
            entries.add(line)
            while (entries.size > MAX_LINES) entries.removeAt(0)
        }
    }

    fun asText(): String = entries.joinToString("\n")

    @Synchronized
    fun clear() {
        runCatching { file?.writeText("") }
        runOnMain { entries.clear() }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }
}
